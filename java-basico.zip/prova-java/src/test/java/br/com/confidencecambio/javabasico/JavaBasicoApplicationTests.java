package br.com.confidencecambio.javabasico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import java.lang.*;

@SpringBootTest
class JavaBasicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
